# Compact A2 source and results

Snapshot: project branch p1-v1.2.2, commit 45d1ada.

This compact package contains the current source, tests, pinned dependencies,
versioned policies, primary/reference inputs, reports, preserved failure reports,
and the final seven-cell A2 summary and per-cell metrics.

Start with project/panda_research/reports/p1_v1.2.2_r4/A2_GO_REVIEW.md.

The reported numerical A2 result is GO in the original validated checkout.
Independent signatures remain unset. The original C4 and finer confirmation
grids pass with unchanged acceptance thresholds.

To keep this download small, portable Git history, old downloadable release
archives, raw per-step simulation traces and redundant run snapshots are not
included. The original repository and full archive remain unchanged.

This is a source-and-results review package. Running the full freeze-integrity
checker, raw-trace audits or full frozen pipeline requires the complete checkout
and its original evidence; those guards have not been bypassed for packaging.

PACKING_MANIFEST.json lists every included file with SHA-256 and all omitted
tracked paths. Source file bytes and scientific acceptance criteria are unchanged.
