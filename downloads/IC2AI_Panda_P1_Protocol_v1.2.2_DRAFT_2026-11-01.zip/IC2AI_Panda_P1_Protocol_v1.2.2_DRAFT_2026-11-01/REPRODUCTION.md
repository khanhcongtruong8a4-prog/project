# Reproduction and limits

Use Linux x86-64 and Python 3.12. Preserve the accepted Action 3 r2 ZIP unchanged:
IC2AI_Panda_Action3_v1.2.1_2026-11-01_r2.zip
SHA-256: 7b96c24e6a56dfbde805ba610d1564b4128c20fe291b01dce4663e2696122292
Base Git commit: cea93d667350d56df7f7de2426f3679ee6eacce0.
The accepted archive remains in the repository's action3-v1.2.1 branch under downloads/.

1. Unpack that ZIP into a fresh disposable directory. It contains panda_research/.
2. Unpack this overlay separately. Run the standard-library installer:

   python APPLY_OVERLAY.py --baseline /path/to/fresh/panda_research

   All package/base/conflict checks complete before writes. Modified original
   files are copied to historical/p1_overlay_baseline/. The installer refuses
   unexpected local edits and supports an idempotent second call.
3. Change to the resulting panda_research directory. Install pinned dependencies:

   python3.12 -m venv .venv
   .venv/bin/python -m pip install -r requirements.lock.txt
   .venv/bin/python -m pip install --no-deps -e .

   Full baseline verification also requires pdftotext (poppler-utils). No GUI,
   ROS, GPU, external credentials or network access is needed after installation.
4. Reproduce only the authorized engineering checks:

   .venv/bin/python scripts/p1_feasibility.py
   .venv/bin/python scripts/check_a2_plan.py
   .venv/bin/python scripts/verify_p1.py

   verify_p1 includes the exact existing command `python scripts/action3.py validate`
   with the current interpreter. It is engineering evidence. An independent reviewer
   must do a separate clean-environment reproduction and sign their own record.
   Exit 0 from check_a2_plan means proposed fields are complete; its official_A2
   output remains NO-GO. It never grants approval.

Each screen/test/check command creates a new runs/ directory. The existing
action3 validate includes its original development tests, model comparisons
and an expected exit-2 A2-entry refusal. These are not a P1 hold or official A2.
Numerical values may vary at roundoff across platforms. Match the same physical
inputs, pair failures, fixed duration, strict QP acceptance, counts and gates;
do not compare timestamped report file hashes as if the execution times matched.

The screen has no plant integration or disturbance-truth query. Negative physical
time is used only in its analytic envelope map. A signed prehold execution adapter
and actual torque-hold validation are absent; no physical startup should be inferred.
Do not run an optimizer, new prehold or official A2 under this draft.

To regenerate unsigned review artifacts after a new screen:

   .venv/bin/python scripts/build_p1_review.py

Keep prior immutable run directories. This changes current report pointers and
checksum bookkeeping, never the approved v1.2.1 policy or predeclaration bytes.
The archive includes report copies of run records and original reviewer inputs;
portable report pointers replace local run paths only. Absolute historical command
paths inside evidence are provenance, not paths you must recreate.
