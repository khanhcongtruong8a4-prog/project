# Panda A2 v2.4b — compact runtime/source package

This is the SMALL download. It contains the unchanged numerical implementation,
all normative policies/inputs, tested native QP libraries, tests, mathematical
notes and lightweight result/failure summaries. Bulk historical traces are
omitted. One original ~11 MB trace fixture is retained for the unchanged v4
unit tests. No stored witness is used as a runtime control fallback.

Linux x86-64 and Python 3.12.14 are the recorded platform. Git is required for
local policy staging. Native libraries and their source/build records are
included. Python dependencies are installed separately (not bundled):

    python3.12 -m venv .venv
    .venv/bin/python -m pip install -r panda_research/requirements-compact.lock.txt
    .venv/bin/python RUN_COMPACT_A2.py --verify-only
    .venv/bin/python RUN_COMPACT_A2.py --prefix my_tests

The default command executes 65 mathematical/audit/legacy contracts plus all
39 T27 fixtures, with real exit-status and test-count checks. No old summary
is substituted for a current test outcome. The minimal dependency lock keeps
the original NumPy/SciPy/CasADi/ProxSuite/cmeel versions; optional independent
Pinocchio/MuJoCo model-review tools use the separate original full lockfile.

To generate one complete new closed-loop trajectory:

    .venv/bin/python RUN_COMPACT_A2.py --candidate alpha10 --cell 0 --prefix my_cell

To regenerate all seven original, twelve extended and eight active-candidate
cells, including refinements and complete guard/KKT/GL audits:

    .venv/bin/python RUN_COMPACT_A2.py --all --prefix my_full_replay

Full numerical replays are computationally substantial and generate large raw
traces LOCALLY. Existing raw result/audit flags and their separately versioned
v2.4a/v2.4b verification corrections are retained honestly in the outputs.
Fail-closed behavior, original dynamics/gains/guards/thresholds and all
mathematical execution functions are unchanged.

## Precisely different provenance scope

COMPACT_MANIFEST.json verifies every included byte and identifies omissions.
The compact plan-file adapter binds ONLY the normative plan loader of the
unchanged numerical function bytecode; it does not change control, dynamics,
integration, constraints or acceptance formulas. Source and normative inputs
are checked before motion. Original historical archive-integrity CLIs cannot
validate omitted raw files. Those integrity gates are explicitly NOT RUN in
the compact flow, never represented as passes. Use this entry point rather
than the older full-history wrappers, which intentionally require the archive.

The previously completed acceptance and failure history are read-only reports.
A new numerical replay gets its own fresh results; there is no new universal
or certified GO merely from unpacking this distribution. No A3 comparisons,
Level1 certificate, hardware timing or certified true-ODE bounds are claimed.

The complete unchanged history remains at the immutable full-source annex:
https://github.com/khanhcongtruong8a4-prog/project/archive/c1d0fd2eb7ac05a955b2d75ce6ff01ea45f543c8.zip
You do NOT need that multi-GB download for the compact test/runtime commands.
