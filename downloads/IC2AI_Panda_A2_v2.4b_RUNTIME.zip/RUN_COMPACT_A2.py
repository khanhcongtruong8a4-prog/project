from pathlib import Path
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'panda_research/scripts'))
from compact_a2_runtime import main
if __name__=='__main__':raise SystemExit(main())
