# Apply and reproduce the cumulative r2 review overlay

Preserve accepted archives. Use a disposable copy of either accepted Action 3 r2
(ZIP SHA-256 7b96c24e6a56dfbde805ba610d1564b4128c20fe291b01dce4663e2696122292)
or that baseline with the accepted P1 r1 overlay already applied
(overlay ZIP SHA-256 ff17fcac4e865825512d321350260b169d4b12065c5af10fcc40a82a91139f05).
Both are available under downloads/ in the repository. Then run:

    python APPLY_OVERLAY.py --baseline /path/to/disposable/panda_research

Checks complete before writes. Only exact accepted base/r1 hashes or already
installed r2 hashes are accepted. Unexpected local edits are refused. Replaced
files are backed up under historical/p1_overlay_r2_baseline/, separately from r1.
Repeated application is idempotent. No cache, virtualenv or cumulative input
source archive is inside this clean overlay.

Use Linux x86-64/Python 3.12, install requirements.lock.txt, install the project
with `python -m pip install --no-deps -e .`, and provide pdftotext/poppler-utils
for full baseline validation. No GUI/ROS/GPU is required. From panda_research/:

    python tests/test_preparation.py --report runs/my_preparation_tests.json
    python scripts/action3.py validate
    python scripts/p1_prehold.py

Create a new directory below runs/ for your test report first. p1_prehold creates
a unique run directory and is EXPECTED TO EXIT 3: the frozen physical-model hold
fails. Exit 0 must never be forced. The first failure is retained for every
predeclared C4 cell. No official A2 or post-hold reference execution is available.
All parameter choices stay fixed; do not retry with a longer duration or easier
tolerance. Model integration is a development test authorized by the remediation
request, not owner/theory/controls approval of startup.

Inspect the actual abort-state diagnostics in each new cell JSON, including
q/qd/z, propagated varpi, h/psi1/speed/manipulability/torque and full QP result.
Physical time -0.15475 s has only 1.25 ms observer elapsed time; never substitute
the planned t=0 bound there. The cubic extension checks are numerical only and
do not certify a continuous ODE neighborhood or sampled observer theorem.

For the current evidence-aware checklist (EXPECTED EXIT 1 because P1 fails):

    python scripts/check_a2_plan.py --policy policy/v1.2.2-r2-draft/PROPOSED_POLICY_CONFIGURATION_v1.2.2_r2.json --preparation-summary reports/p1_v1.2.2_r2/evidence/prehold/summary.json --clock-tests reports/p1_v1.2.2_r2/evidence/signed_clock_and_hold_tests.json

Default older check/verify scripts can still reproduce the r1 analytical draft;
they do not override the newer r2 failure disposition. Fresh engineering
reproduction is not an independent reviewer's signature. The three human
actions and build-revision packet remain necessary before any future A2 GO.
