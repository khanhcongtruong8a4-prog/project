# Small pre-A3 numerical reproduction

This subset includes all core source and inputs for numerical reproduction
and fresh development simulation. Raw recorded CTZ files are in the separate
task evidence ZIP. The complete older history remains in the immutable annex
listed in HISTORICAL_ANNEX.json. Neither large download is needed for the
numerical commands below.

Read panda_research/reports/pre_a3_blockers_v1/ISSUE_RESOLUTION_REPORT.md.
A2's frozen 19-cell GO is retained. Active-filter refinement, M1 bound
qualification, G2.5 and A3 are NO-GO. All 39 finite T27 fixtures pass.
No independent signatures, official A3 experiments or Level1 claims.

With Linux / Python3.12.14 and the unchanged pinned dependency versions:

    python -m venv .venv
    .venv/bin/python -m pip install -r panda_research/requirements.lock.txt setuptools==80.9.0
    .venv/bin/python RUN_PRE_A3.py --verify-only
    .venv/bin/python RUN_PRE_A3.py --run-numerics --prefix my_numerical_replay

The numerical command runs 14 contracts and 39 T27 fixtures, rebuilds all 14
M1 entries, reproduces the held-out failures and all 1,212 G2.5 point checks,
and confirms the fail-closed planner gate. Reproducing a NO-GO is a successful
reproduction, never a promotion of a failed experiment to acceptance.

Optional fresh four-candidate/two-ladder simulation (exclusive new outputs):

    .venv/bin/python RUN_PRE_A3.py --run-dynamics --prefix my_six_cell_replay

Dynamic replay creates explicitly labeled LOCAL Git metadata for the frozen
new declarations. It does not reconstruct historical commits or signatures.
The rejected sampler remains rejected. Recorded legacy-trace diagnosis with
--restore/--diagnose-legacy requires the task evidence ZIP. The old historical
frozen CLIs need their full original data/annex and retain their original checks.
