# Small runnable guarded-QP reproduction

This subset contains corrected source, the tested Linux x86_64 native backend,
its build recipe, policies, read-only reports and all 39 qualification fixtures.
Full original/extended trajectory traces and large historical archives are in
the separate COMPLETE evidence ZIP. This subset cannot replay the 23 motions.

With the recorded Linux/Python 3.12.14 environment:

    python -m venv .venv
    .venv/bin/python -m pip install -r panda_research/requirements.lock.txt setuptools==80.9.0
    .venv/bin/python RUN_REMEDIATION.py --qp-only --prefix my_solver_check

Read panda_research/reports/guarded_qp_reliability_v1/READINESS_DECISION.md for
the separate A2, solver-qualification, T27 and A3 decisions. No external review
signatures or Level 1 certification are claimed. Every included byte is covered
by QP_SUBSET_MANIFEST.json; the subset manifest itself excludes its own hash.
