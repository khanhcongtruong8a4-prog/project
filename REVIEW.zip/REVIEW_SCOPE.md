Small code/policy/table subset only. Raw traces and prior protected input archives are in the complete package evidence/ payload. This subset cannot run full reproduction.
